#include <stdio.h>

void main (){
	int num1,num2,soma;
	printf("Informe o valor do primeiro numero= ");
	scanf("%d",&num1);
	printf("Informe o valor do segundo numero= ");
	scanf("%d",&num2);
	soma=num1+num2;
	printf("%d+%d= %d",num1,num2,soma);
}
