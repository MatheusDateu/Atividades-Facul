#include <stdio.h>

void main(){
	int i;
	for (i=1;i <=1000; i++)
	printf("Boa noite\n");
 }
