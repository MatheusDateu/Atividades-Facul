#include <stdio.h>

void main(){
	int num;
	printf("Informe o valor do numero= ");
	scanf("%d",&num);
	if(num>=0){
		printf("Positivo");
	}else{
		printf("Negativo");
	}
}
