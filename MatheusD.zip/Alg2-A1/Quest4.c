#include <stdio.h>

void main(){
	int num;
	printf("Informe o valor de um numero= ");
	scanf("%d",&num);
	if(num>=10){
		printf("Sim-E maior ou igual a 10");
	}
}
